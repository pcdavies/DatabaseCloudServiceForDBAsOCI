#!/bin/bash

sqlplus system/ALpha2018__@pdb1 << EOF

create tablespace alpha_archive datafile '+data';

create user alpha_archive identified by ALpha2018__ default tablespace alpha_archive;

grant dba to alpha_archive;

EOF

impdp alpha_archive/ALpha2018__@pdb1 directory=tmp dumpfile=oci_ws_alpha.dmp remap_schema=alpha:alpha_archive remap_tablespace=users:alpha_archive
