#!/bin/bash

#
sudo chown oracle /tmp/alpha/oci_*
sudo chown oracle /tmp/alpha/privateKey
sudo chmod -R a+rw /tmp/alpha
sudo chmod 600 /tmp/alpha/privateKey
sudo chmod a+x /tmp/alpha/oci_alpha_install.sh
sudo chmod a+x /tmp/alpha/oci_alpha_install_as_oracle.sh

/tmp/alpha/oci_alpha_install_as_oracle.sh

