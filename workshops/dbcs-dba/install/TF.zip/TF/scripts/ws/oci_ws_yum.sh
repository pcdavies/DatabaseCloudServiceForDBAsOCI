#!/bin/bash


yum -y -q groupinstall "Desktop" "General Purpose Desktop"
yum -y -q install tigervnc-server firefox flash-plugin python expect
yum -y -q remove gnome-screensaver
yum clean all
yum clean metadata

# stop annoying pop up message about yum updates
echo X-GNOME-Autostart-enabled=false>>/etc/xdg/autostart/gpk-update-icon.desktop

