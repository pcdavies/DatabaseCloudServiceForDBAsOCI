#!/usr/bin/expect -f

# start remote session

spawn sudo su - oracle

# update tnsnames.ora

send "cp /u01/app/oracle/product/12.2.0.1/dbhome_1/network/admin/tnsnames.ora /u01/app/oracle/product/12.2.0.1/dbhome_1/network/admin/tnsnames.ora_bu\r"
expect "$ "
sleep 1

send "cat /tmp/ws/oci_ws_tnsnames.ora >>/u01/app/oracle/product/12.2.0.1/dbhome_1/network/admin/tnsnames.ora\r"
expect "$ "
sleep 1

# send "cp /u01/app/oracle/product/18.1/dbhome_1/network/admin/tnsnames.ora /u01/app/oracle/product/18.1/dbhome_1/network/admin/tnsnames.ora_bu\r"
# expect "$ "
# sleep 1

# send "cat /tmp/ws/oci_ws_tnsnames.ora >>/u01/app/oracle/product/18.1/dbhome_1/network/admin/tnsnames.ora\r"
# expect "$ "
# sleep 1

# set environment variables for sql execution

send "export ORACLE_SID=ORCL\r"
expect "$ "
sleep 1

send "export ORACLE_BASE=/u01/app/oracle\r"
expect "$ "
sleep 1

send "export ORACLE_HOME=/home/oracle\r"
expect "$ "
sleep 1

send "ORAENV_ASK=NO\r"
expect "$ "
sleep 1

send ". oraenv\r"
expect "$ "
sleep 1

# create database objects

send "sqlplus system/ALpha2018__@pdb1 @/tmp/ws/oci_ws_install.sql\r"
expect "$ "
sleep 1

# import data into alpha

send "impdp alpha/ALpha2018__@pdb1 directory=tmp dumpfile=oci_ws_alpha.dmp remap_tablespace=users:alpha\r"
expect "$ "
sleep 60

# set vncserver password and start it

send "vncpasswd\r"
expect "Password:"
send "$1\r"
expect "Verify:"
send "se4oracle\r"
expect "$ "
sleep 1

send "vncserver :1\r"
expect "$ "
sleep 1

send "exit\r"

