#!/bin/bash

# yum
sudo cp /tmp/ws/oci_ws_public-yum-ol6.repo /etc/yum.repos.d/public-yum-ol6.repo
sudo rpm -ivh /tmp/ws/oci_ws_adobe-release-x86_64-1.0-1.noarch.rpm
sudo chmod -R a+rw /tmp/ws
sudo chmod +x /tmp/ws/oci_ws_yum.sh
sudo /tmp/ws/oci_ws_yum.sh
sudo killall gnome-screensaver

# Firewall
sudo sed -i 's/IPTABLES_SAVE_ON_RESTART="no"/IPTABLES_SAVE_ON_RESTART="yes"/g' /etc/sysconfig/iptables-config
sudo iptables -I INPUT -p tcp -m tcp --dport 5901 -j ACCEPT
sudo service iptables restart

#
sudo chown oracle /tmp/ws/oci_ws_*
sudo chown oracle /tmp/ws/privateKey
sudo chmod 600 /tmp/ws/privateKey
sudo chmod a+x /tmp/ws/oci_ws_install_as_oracle.sh

/tmp/ws/oci_ws_install_as_oracle.sh $1
