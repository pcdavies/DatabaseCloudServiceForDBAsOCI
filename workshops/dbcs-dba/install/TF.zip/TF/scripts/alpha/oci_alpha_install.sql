create tablespace alpha datafile '+data';
-- defaults 100mb, unlimited

create user alpha identified by ALpha2018__ default tablespace alpha;

grant dba to alpha;

create directory tmp as '/tmp/alpha';

grant all on directory tmp to public;

exit;

