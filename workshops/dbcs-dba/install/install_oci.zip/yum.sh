#!/bin/bash


yum -y groupinstall "Desktop" "General Purpose Desktop"
yum -y install tigervnc-server firefox flash-plugin
yum clean all
yum clean metadata

# stop annoying pop up message about yum updates
echo X-GNOME-Autostart-enabled=false>>/etc/xdg/autostart/gpk-update-icon.desktop

