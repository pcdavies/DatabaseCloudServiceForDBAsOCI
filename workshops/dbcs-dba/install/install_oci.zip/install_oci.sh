#!/bin/bash

# create user and tablespace

sqlplus system/ALpha2018__@pdb1 << EOF

create tablespace alpha datafile '+data';
-- defaults 100mb, unlimited

create user alpha identified by ALpha2018__ default tablespace alpha;

grant dba to alpha;

create directory oracle as '/home/oracle';

grant all on directory oracle to public;

EOF

# import data
impdp alpha/ALpha2018__@pdb1 directory=oracle dumpfile=alpha.dmp remap_tablespace=users:alpha



