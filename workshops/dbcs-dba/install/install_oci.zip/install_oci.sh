#!/bin/bash

# create user and tablespace

vi /u01/app/oracle/product/12.2.0.1/dbhome_1/network/admin/tnsnames.ora

sqlplus system/ALpha2018__@pdb1 << EOF

create tablespace alpha datafile '+data';
-- defaults 100mb, unlimited

create user alpha identified by ALpha2018__ default tablespace alpha;

grant dba to alpha;

create directory tmp as '/tmp';

grant all on directory tmp to public;

EOF

-- update /u01/app/oracle/product/12.2.0.1/dbhome_1/network/admin/tnsnames.ora - add pdb1

# import data
impdp alpha/ALpha2018__@pdb1 directory=tmp dumpfile=alpha.dmp remap_tablespace=users:alpha



