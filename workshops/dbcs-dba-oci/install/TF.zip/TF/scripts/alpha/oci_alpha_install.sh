#!/bin/bash

# change permissions, ownership
sudo chown oracle:oinstall /tmp/alpha
sudo chown oracle:oinstall /tmp/alpha/*
sudo chmod -R a+rw /tmp/alpha/*
sudo chmod a+rw /tmp/alpha/
sudo chmod 600 /tmp/alpha/privateKey

# update tnsnames.ora
sudo su - oracle -c "cp /u01/app/oracle/product/12.2.0.1/dbhome_1/network/admin/tnsnames.ora /u01/app/oracle/product/12.2.0.1/dbhome_1/network/admin/tnsnames.ora_bu"
sudo su - oracle -c "cat /tmp/alpha/oci_alpha_tnsnames.ora >>/u01/app/oracle/product/12.2.0.1/dbhome_1/network/admin/tnsnames.ora"

# create database objects
 sudo su - oracle -c "export ORACLE_SID=ORCL && export ORAENV_ASK=NO && . /usr/local/bin/oraenv && exit | sqlplus system/ALpha2018__@pdb1 @/tmp/alpha/oci_alpha_install.sql"

# import data into alpha
sudo su - oracle -c "export ORACLE_SID=ORCL && export ORAENV_ASK=NO && . /usr/local/bin/oraenv && exit | impdp alpha/ALpha2018__@pdb1 directory=tmp dumpfile=oci_alpha.dmp remap_tablespace=users:alpha"

echo "oci_alpha_install.sh complete"
