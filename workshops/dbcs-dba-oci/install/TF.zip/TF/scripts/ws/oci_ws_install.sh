#!/bin/bash

# yum
sudo cp /tmp/ws/public-yum-ol6.repo /etc/yum.repos.d/public-yum-ol6.repo
sudo rpm -ivh /tmp/ws/adobe-release-x86_64-1.0-1.noarch.rpm
sudo chown oracle:oinstall /tmp/ws
sudo chown oracle:oinstall /tmp/ws/*
sudo chmod -R a+rw /tmp/ws
sudo chmod 600 /tmp/ws/privateKey
sudo chmod +x /tmp/ws/*.sh
sudo /tmp/ws/oci_ws_yum.sh
sudo wait #PID
sudo killall gnome-screensaver

# Firewall
sudo sed -i 's/IPTABLES_SAVE_ON_RESTART="no"/IPTABLES_SAVE_ON_RESTART="yes"/g' /etc/sysconfig/iptables-config
sudo iptables -I INPUT -p tcp -m tcp --dport 5901 -j ACCEPT
sudo service iptables restart

# update tnsnames.ora
sudo su - oracle -c "cp /u01/app/oracle/product/12.2.0.1/dbhome_1/network/admin/tnsnames.ora /u01/app/oracle/product/12.2.0.1/dbhome_1/network/admin/tnsnames.ora_bu"
sudo su - oracle -c "cat /tmp/ws/oci_ws_tnsnames.ora >>/u01/app/oracle/product/12.2.0.1/dbhome_1/network/admin/tnsnames.ora"

# create database objects
 sudo su - oracle -c "export ORACLE_SID=ORCL && export ORAENV_ASK=NO && . /usr/local/bin/oraenv && exit | sqlplus system/ALpha2018__@pdb1 @/tmp/ws/oci_ws_install.sql"

# import data into alpha
sudo su - oracle -c "export ORACLE_SID=ORCL && export ORAENV_ASK=NO && . /usr/local/bin/oraenv && exit | impdp alpha/ALpha2018__@pdb1 directory=tmp dumpfile=oci_ws_alpha.dmp remap_tablespace=users:alpha"

# setup and start vnc
sudo su - oracle -c "mkdir .vnc"
sudo su - oracle -c "echo $1|vncpasswd -f > /home/oracle/.vnc/passwd"
sudo su - oracle -c "chmod 600 /home/oracle/.vnc/passwd"
sudo su - oracle -c "vncserver :1"

echo "oci_ws_install.sh complete"
