#!/bin/bash

# create user and tablespace

sqlplus system/ALpha2018__@pdb1 << EOF

create tablespace alpha datafile '+data';
-- defaults 100mb, unlimited

create user alpha identified by ALpha2018__ default tablespace alpha;

grant dba to alpha;

create directory tmp as '/tmp/ws';

grant all on directory tmp to public;

EOF

# import data
impdp alpha/ALpha2018__@pdb1 directory=tmp dumpfile=oci_ws_alpha.dmp remap_tablespace=users:alpha



